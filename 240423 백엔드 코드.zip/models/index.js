const { sequelize } = require('./connection');
const Department = require('./department');
const User = require('./user');

const db = {};

db.sequelize = sequelize;

db.Department = Department;
db.User = User;

// Department.init(sequelize);
// User.init(sequelize);
Object.keys(db).forEach((modelName) => {
  if (db[modelName].init) {
    db[modelName].init(sequelize);
  }
});
// 관계 설정
// Department.associate(db);
// User.associate(db);

Object.keys(db).forEach((modelName) => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});
module.exports = db;
