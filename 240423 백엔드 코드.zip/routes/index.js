const express = require('express');
const logger = require('../lib/logger');
const departmentRouter = require('./department');
const userRouter = require('./user');
const authRouter = require('./auth');

const router = express.Router();

router.use('/departments', departmentRouter);
router.use('/users', userRouter);
router.use('/auths', authRouter);

/* GET home page. */
router.get('/', (req, res, next) => {
  res.render('index', { title: 'Express' });
});

router.get('/log-test', (req, res, next) => {
  logger.error('에러입니다.');
  logger.warn('경고입니다!');
  logger.info('정보로그입니다!');
  logger.debug('로그테스트 debug!');

  logger.silly('로그테스트 silly!');
  logger.verbose('로그테스트 verbose!');
  res.send('log test ok!');
});

router.get('/log-error', (req, res, next) => {
  logger.error('test log error');
  // 로직들 여기에 입력
  // service 로직
  res.send('log test ok!');
});
router.get('/log-warn', (req, res, next) => {
  logger.warn('test log warn');
  res.send('log test ok!');
});
router.get('/log-info', (req, res, next) => {
  logger.info('test log info');
  res.send('log test ok!');
});
router.get('/log-debug', (req, res, next) => {
  logger.debug('test log debug');
  res.send('log test ok!');
});

module.exports = router;
